Important
---------

Customer Detail files are saved in "Customer Details" folder.
